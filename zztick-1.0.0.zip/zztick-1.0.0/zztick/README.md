# Zztick (Ashita v4 addon for FFXI)

A small window that appears only while you're resting (`/heal`). It shows:

- a countdown to the next recovery tick (one decimal) plus a progress bar
- your HP and MP now -> what they'll be after the next tick, with the gain (+N)
- how many ticks and how long until you're full (optional)

## Install

1. Copy the `addons/zztick` folder into your Ashita install so you have:
   - `Ashita/addons/zztick/zztick.lua`, `zzmodel.lua`, `zzfonts.lua` and `zzstyle.lua`
   - the `fonts/` folder (bundled fonts and their licenses; you can add your own .ttf/.otf files there
     too)
2. In game: `/addon load zztick`
3. To load it automatically, add this line to your startup script (usually
   `Ashita/scripts/default.txt`, in the addon load section): `/addon load zztick`
4. Type `/zztick test` to show a preview while standing, drag it where you want, then `/zztick lock`.

### Editing the settings file by hand

Settings are saved per character in `Ashita/config/addons/zztick/<Name>_<ServerId>/settings.lua`.
You can edit it while the addon is unloaded. On load (and on character switch) every value is checked:
numbers saved as text are read as numbers, out-of-range numbers are clamped to the ranges the config
window uses, values of the wrong type or unknown choices go back to their defaults, and keys Zztick
doesn't use are removed. If anything was changed, one chat line names each key, for example
`Fixed invalid settings (hand edit?): rounding: 500 out of range, set to 16.` and the fixed file is saved.

## Commands

| Command | What it does |
| --- | --- |
| `/zztick` | Help |
| `/zztick config` | Open/close the settings window (everything below is also there) |
| `/zztick lock` / `unlock` | Lock or unlock the window position |
| `/zztick test` | Toggle a preview window with sample numbers (for positioning) |
| `/zztick test sync` | Preview with the "Synced Lv 30" badge |
| `/zztick sync on` / `off` | Show the "Synced Lv NN" badge under Level Sync / Level Restriction (default on) |
| `/zztick subratio <0-3>` | Server subjob ratio (LSB `SUBJOB_RATIO`: 0 none, 1 half (default), 2 two-thirds, 3 equal) |
| `/zztick bonus hp <n>` | Extra HP per tick the gear scan can't see (food, latent/set gear) |
| `/zztick bonus mp <n>` | Extra MP per tick |
| `/zztick scale <n>` | Window scale, 0.5 to 3 |
| `/zztick compact` | Toggle one-line compact mode |
| `/zztick fonts` | List the fonts you can pick |
| `/zztick font <name>` / `font default` | Pick a font (live, no reload) |
| `/zztick fontsize <n>` | Font size in pixels, 0 = Ashita's default (default 16) |
| `/zztick titlefont <name>` / `numfont <name>` | Font for the "Resting" title / for the numbers |
| `/zztick theme <name>` | `Vana'diel Gold` (default), `Crystal Blue`, `Midnight`, `Ember Forge`, `Windurst Verdant`, `Bastok Steam`, `Jeuno Twilight`, `Abyssea`, `Classic` (short names like `gold`, `ember`, `windurst`, `bastok`, `jeuno`, `abyssea` work) |
| `/zztick width <px>` / `width auto` | Override the fixed window width (auto = sized for the widest possible numbers) |
| `/zztick animate` | Toggle animations (smooth bar, last-second glow, +gain pop) |
| `/zztick fade <ms>` | Fade-in/out time, 0 = instant (default 150) |
| `/zztick debug` | Toggle a performance readout (ms per frame, scan/save counters) |
| `/zztick profile lsb` / `retail` | LandSandBoat (private server, default) or retail formulas |
| `/zztick chime on` / `off` / `test` | Soft chime when fully healed, once per rest (on by default). `test` always plays and prints diagnostics |
| `/zztick chime backend auto\|ashita\|winmm` | How sounds are played (auto = Ashita, then winmm `PlaySoundA`) |
| `/zztick chime mode both\|any\|hp\|mp` | When it plays: both full (default), either one, or only HP / MP |
| `/zztick chime sound <file>` / `list` | Pick a `.wav` from `addons/zztick/sounds/`. You can drop your own files there |
| `/zztick chime sitfull on\|off` | Also chime when you sit down already full |
| `/zztick arrow` / `icons` | Toggle the drawn arrow, the heart/droplet icons |
| `/zztick fx border\|sparkle\|both\|off` | Effect when HP/MP reaches full (default `border`: a comet runs around the window) |
| `/zztick test flash` (or `flash test`) / `test sparkle` | Replay the border flash / sparkle, no chime (opens the preview if you're standing) |
| `/zztick debug flash` | Print the flash rect, window pos/size, io.DisplaySize and DisplayFramebufferScale |
| `/zztick info` | Print what the model is using: jobs, real vs effective (synced) levels and their source, Clear Mind tier, gear bonuses, tick 1 values |
| `/zztick reset` | Reset settings to defaults |

## Configuration (`/zztick config`)

Saved per character by Ashita's `settings` library
(`Ashita/config/zztick/<CharName>_<serverid>/settings.lua`).

- **Window:** lock, title bar on/off, compact mode (always fits its one row; the width override comes back when it is off), scale, background opacity, bar height, width override
  (shows the auto width), exact X/Y
- **Look:** theme, animations on/off, fade time, corner rounding, HP/MP mini bars
- **Font:** body, title and numbers fonts, size, bold, outline and outline color (see Fonts below)
- **Lines:** countdown, progress bar, HP, MP, gain amounts, tick number, ticks/time to full,
  and a diagnostic "last observed gain vs expected" line
- **Colors (Classic theme):** text, timer, HP, MP, bar, bar background. The other themes use their own palettes.
- **Recovery model:** manual HP/MP bonus, auto gear scan on/off, Signet/Sigil bonus (Auto/Always/Never),
  Retail vs LandSandBoat rules, BLU Clear Mind tier, first-tick delay and tick interval

### Sound (v1.0.0)

The **Sound** section of `/zztick config` has a **Chime when fully healed** checkbox (`chime_enabled`, saved per
character). It also has the "when" mode, the sound picker, a **Test chime** button and **Also when sitting down
already full**. Sounds play through Ashita v4's `ashita.misc.play_sound(path)`, which calls Windows
`PlaySoundA(SND_FILENAME | SND_ASYNC)`. That only plays `.wav` files and has no volume control, so the bundled
chimes are pre-scaled to a peak of -6 dBFS. To change the volume of a custom sound, edit the file itself.
If Ashita's call is missing or fails, Zztick falls back to winmm `PlaySoundA` through LuaJIT ffi.

**Troubleshooting (no chime):**
1. Run `/zztick chime test`. It always plays and prints the full path, whether the file was found, its size and
   format, and how it was played. Expected output:
   `Chime test: C:\...\Ashita\addons\zztick\sounds\chime_soft.wav` /
   `file: found, 57374 bytes, PCM 16-bit, 1 ch, 44100 Hz` /
   `played via ashita.misc.play_sound: called (returns nothing)` / `full-heal chime is ON, mode both`.
2. If the test is audible but nothing plays when you're healed, run `/zztick info` while resting. The `Chime:` line
   shows on/off, the mode, whether HP/MP count as full, and whether it is "armed, waiting for full" or
   "played this rest". With mode `both` on a job with MP, it waits for MP too. Use `/zztick chime mode any`
   or `hp` to change that.
3. Sounds play in FFXI's own audio session. The game's in-game sound setting and Windows' notification or
   "System Sounds" settings don't affect it. Muting or lowering **pol.exe** / FFXI in the Windows Volume
   Mixer does, and so does the output device.
4. Custom files must be plain PCM `.wav` (8 or 16-bit). Float or 24-bit WAVs may not play.
The two bundled chimes (`chime_soft.wav`, `chime_bell.wav`) were synthesized for Zztick by
`tools/make_chimes.py` and are CC0.

## How it works

### Detecting resting
Every frame it reads your entity status
(`AshitaCore:GetMemoryManager():GetEntity():GetStatus(GetParty():GetMemberTargetIndex(0))`).
Status `33` is Resting. Anything else hides the window and resets the timer. It also
hides while `GetPlayer():GetIsZoning()` is set.

### Tick timing
- When status becomes 33 the timer starts: first tick in **20s**, then every **10s**.
- It watches your HP/MP (`GetParty():GetMemberHP(0)` / `GetMemberMP(0)`). When they go up in a way
  that looks like a healing tick, the timer re-syncs to that moment. "Looks like a tick" means:
  - at least 12s after you sat down for the first tick, or 7s after the previous tick (so Regen,
    Refresh, or a Cure in between don't count), and
  - at least half the expected gain, or it topped you off.
  - A HP update followed by a separate MP update a moment later counts as one tick.
- The countdown is optimistic: the moment the expected tick time arrives it rolls straight
  into the next 10s interval. It never sits at 0.0 waiting for the HP/MP packet.
- That tick is then "pending" for up to 4s. Until its HP/MP gain arrives, the HP/MP lines
  already include it, so the numbers don't flicker. When the gain arrives, the timer re-syncs
  quietly and the tick isn't counted twice. If you're already full, nothing arrives and the
  timer just keeps going.
- **Display bar (1.2.1):** the bar's fill is kept separately from the timer model.
  - Each frame it spreads the unfilled part over the time left to the *corrected* next tick:
    `p += (1 - p) * dt / (next_tick - last_frame)`.
  - A re-sync only changes the fill rate, never the fill itself. The bar lands on exactly 1.0 at the
    corrected tick time, and goes back to 0 only at that rollover.
  - If the real tick comes *earlier* than modelled, the bar speeds up and finishes within 0.25s, then
    starts the next interval.
  - The countdown text always shows the true corrected time. It can tick up a little after a late gain,
    but the bar never goes backwards.
  - The last-second glow uses the true remaining time.
  - This applies to every theme, Classic and the test preview.

### Formulas
Tick `n` is the n-th recovery while resting (n = 1 is the one ~20s after `/heal`).

**HP per tick** (normal):
`10 + (n - 1) + hHP`

**HP per tick with Signet** (in its regions):
- LandSandBoat (default profile, `scripts/effects/healing.lua` lines 75-79): Signet or Sigil only,
  `10 + 3*floor(level/10) + (n-1) * (1 + floor(MaxHP/300)) + hHP` (no cap on the rate).
- Retail (BG-Wiki): Signet, Sanction or Sigil, `10 + 3*floor((level-1)/10) + (n-1) * min(5, 1 + floor(MaxHP/300)) + hHP`.
- At levels 10, 20, ... 70 the retail level term is exactly 3 lower than LSB's.
- `/zztick info` prints each term for the next tick so you can compare with the real gain.

**MP per tick** (only if Max MP > 0):
`12 + (n - 1) * (1 + CM_tick) + CM_base + hMP`

| Clear Mind | CM_base | CM_tick | Example ticks |
| --- | --- | --- | --- |
| none | 0 | 0 | 12, 13, 14 |
| I | +3 | 0 | 15, 16, 17 |
| II | +6 | 0 | 18, 19, 20 |
| III | +9 | +1 | 21, 23, 25 |
| IV | +12 | +1 | 24, 26, 28 |
| V | +15 | +2 | 27, 30, 33 |
| VI | +18 | +3 | 30, 34, 38 |

Clear Mind levels (retail, BG-Wiki): WHM 20/35/50/65/80/96, BLM 15/30/45/60/75/96,
RDM 31/53/75/91, SMN 15/30/45/60/75/91, SCH 20/35/50/65/76/91, GEO 20/40/60/80/99.
Main and support job are both checked (support at its own level). BLU gets Clear Mind
from set spells, so you set its tier in the config.

- **hHP / hMP** = "HP/MP recovered while healing +N" from your equipped gear (read from the
  item descriptions; only unconditional lines count) + your manual bonus.
- Disease, Plague, or Curse II (zombie) = no recovery; the window says so.
- Projected value = current + gain, capped at max. The (+N) shown is the capped gain.

### Sources
- BG-Wiki, Clear Mind: https://www.bg-wiki.com/ffxi/Clear_Mind
- BG-Wiki, HP Recovered While Healing: https://www.bg-wiki.com/ffxi/HP_Recovered_While_Healing
- Gamer Escape, HP Recovered While Healing: https://ffxi.gamerescape.com/wiki/HP_Recovered_While_Healing
- Gamer Escape, Tick (20s first tick, then 10s): https://ffxi.gamerescape.com/wiki/Tick
- LandSandBoat server, healing effect: https://github.com/LandSandBoat/server/blob/base/scripts/effects/healing.lua
- LandSandBoat server, traits table (Clear Mind values): https://github.com/LandSandBoat/server/blob/base/sql/traits.sql
- Ashita v4 addons and API annotations (petinfo, distance, equipmon, settings.lua, imgui.lua,
  annotations/SDK/Memory/*.lua): https://github.com/AshitaXI/Ashita-v4beta
- Windower resources (status 33 = Resting, buff ids, item description wording):
  https://github.com/Windower/Resources

## Fonts

### Bundled fonts (v1.2)
These Google Fonts ship in `addons/zztick/fonts/`, as static TTFs (not variable fonts, for ImGui).
All are under the SIL Open Font License 1.1, and the license texts are in `fonts/licenses/`.

| Font | Used for | Files | Why | Source |
| --- | --- | --- | --- | --- |
| **Barlow Semi Condensed** | body/labels (default) | Regular, SemiBold | Compact and very legible at small sizes; the semi-condensed width keeps the overlay narrow | google/fonts `ofl/barlowsemicondensed` |
| **Cinzel** | title (default) | Regular, Bold | Roman-inscription capitals with a fantasy feel that suits FFXI, still legible; used for the header only | NDISCOVER/Cinzel `fonts/ttf` (the designer's repo, which google/fonts tracks) |
| **JetBrains Mono** | numbers (default) | Regular, Bold | Every digit has the same width, so countdowns and HP never jitter | JetBrains/JetBrainsMono `fonts/ttf` |
| **Inter** | optional clean UI sans | Regular, SemiBold | A neutral UI font if you prefer it for the body | rsms/inter v4.1 release (`extras/ttf`) |

Inter's and Barlow's digits are proportional by default; their tabular figures are an OpenType
feature that ImGui can't switch on. That's why numbers get their own font (JetBrains Mono) and
right-aligned columns.

Credits: Barlow by Jeremy Tribby; Cinzel by Natanael Gama; JetBrains Mono by JetBrains (Philipp
Nurullin, Konstantin Bulenkov); Inter by Rasmus Andersson. Copyright notices are in each license file.

The fonts add about 1.7 MB to the addon folder. The bundled files and their licenses are left
unmodified.

### How fonts load

Zztick uses Ashita's own ImGui helper `imgui.AddFontFromFileTTF(file, size)` (an "Ashita
Custom Helper" on IGuiManager in current Ashita v4, ImGui 1.92 with dynamic font sizes), then
`imgui.PushFont(font, size)` around the window's contents.

- **Three slots:** body (labels and Classic text), title ("Resting" header) and numbers. If the title
  or numbers font can't load, that part uses the body font. If the body font can't load, it uses
  Ashita's font, and the config window says why.
- **Choices:** Default (Ashita), the bundled fonts above, plus Arial, Segoe UI, Consolas, Tahoma, Verdana, Calibri,
  Trebuchet MS, Georgia and Courier New if they exist in `C:\Windows\Fonts`, plus any
  `.ttf`/`.otf` you put in `Ashita/addons/zztick/fonts/` (press **Rescan fonts** or run
  `/zztick fonts`).
- **Size:** any pixel size, multiplied by the window scale. 0 = Ashita's default size.
- **Bold:** uses the font's bold file (for example `arialbd.ttf`) when there is one. Otherwise
  it fakes bold by drawing the text twice, 1px apart.
- **Outline:** draws four 1px offset copies in the outline color behind each line.
- **Live:** changes apply on the next frame, with no reload. The choice is saved per character.
- **Safety:** a font file is checked to exist before ImGui touches it, because ImGui asserts
  on a missing file. Each file is loaded at most once per session, and failures are remembered,
  not retried. A missing or broken font falls back to the default and the config window says why.
- **Older Ashita builds** without `AddFontFromFileTTF`: font choice is disabled (the config says
  so), while size and scale still work through `SetWindowFontScale`. In that case you can
  change ImGui's font for all of Ashita in `Ashita/config/boot/*.ini` under `[ashita.imgui.fonts]`
  (`font0.family = YourFont.ttf`, with the file in `Ashita/resources/fonts/`).
- I didn't use gdifonts (ThornyFFXI). It needs bundled native code, and its own docs warn it's
  slower for text that changes every frame, which is exactly what a countdown does.
- Fonts loaded through ImGui stay loaded until Ashita restarts. Switching between many fonts
  in one session uses a bit more memory, but that's harmless.